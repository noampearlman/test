simp:
 adding 2 numbers - done
 subtracting 2 numbers - done

comp:
 sum of digits in number - done
 check if palindrome - done

col.py module:
    zip - done

unit test - done

no comp before simp rule - done
 