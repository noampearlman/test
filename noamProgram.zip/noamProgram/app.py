import os
from tools import col
from tools.numbers import simp,comp

def main():
    os.system('cls')

    # variable that notates whether a simp function was used
    usedSimp = False
    while(True):
        print('-------------------------------------------')
        print('menu: ')
        print('u - unit test')
        print('sa - simp add 2 numbers')
        print('ss - simp subtract with 2 numbers')
        print('cs - comp sum of digits in number')
        print('cp - comp check if a number is a palindrome')
        print('x - exit')
        print('-------------------------------------------')

        userSelection = input('select option: ')
        os.system('cls')
        # testing all functions 
        if userSelection == 'u':
            print('-------------------------------------------')
            print('unit test: ')
            print('2 + 3 =',simp.add2(2,3))
            print('5 - 4 =',simp.sub2(5,4))
            print('sum of digits 1234 is:',comp.sumofdigits(1234))
            print('is 1234 a palidrome?',comp.isPal(1234))
            print('is 1221 a palidrome?',comp.isPal(1221))
            print('is 12321 a palidrome?',comp.isPal(12321))
            it1 = ("John", "Charles", "Mike")
            it2 = ("Jenny", "Christy", "Monica")
            print('unzipped:',it1,it2)
            print('zipped:',col.myzip(it1,it2))
        
        #add 2
        if userSelection == 'sa':
            usedSimp = True
            print('simp add2 function')
            print(simp.add2(input('enter first number: '), input('enter second number: ')))
        
        #subtract 2
        if userSelection == 'ss': 
            usedSimp = True
            print('simp sub2 function')
            print(simp.sub2(input('enter first number: '), input('enter second number: ')))
            
        #sum of digits
        if userSelection == 'cs':
            if usedSimp:
                print('comp sumofdigits function')
                print(comp.sumofdigits(input('enter number: ')))
            else: 
                print('-------------------------------------------')
                print('cant use a comp function before using a simp function ')

        #check if palindrome
        if userSelection == 'cp':
            if usedSimp:
                print('comp isPal function')
                print(comp.isPal(input('enter number: ')))
            else: 
                print('-------------------------------------------')
                print('cant use a comp function before using a simp function ')

        #exit the program
        if userSelection == 'x': return

if __name__ == "__main__":
    main()