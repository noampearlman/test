def add2(x,y):   
    return int(x)+int(y)

def sub2(x,y):   
    return int(x)-int(y)
