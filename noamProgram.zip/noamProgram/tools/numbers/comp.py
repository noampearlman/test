def sumofdigits(num):
    sum = 0
    try:
        for x in str(num):
            sum+=int(x)
    except:
        pass
    return sum
def isPal(inp):
    
    palin = str(inp)
    # Run loop from 0 to len/2
    for i in range(0, int(len(palin)/2)):
        if palin[i] != palin[len(palin)-i-1]:
            return False
    return True
