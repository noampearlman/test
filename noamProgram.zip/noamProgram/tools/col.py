def myzip(it1 , it2) :
    # return a list of the zip
    return list(zip(it1, it2))

